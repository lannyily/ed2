#ifndef TESTE_H
#define TESTE_H

#include "artista.h"

void testeTemposInsercao();
void testeBuscaMusicasDeArtista(Artista* raiz);

#endif